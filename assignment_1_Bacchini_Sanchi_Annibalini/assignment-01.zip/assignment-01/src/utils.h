
/**
 * Function to create a pseudo-random order to turn off leds
 */
void randomizeOrder(int turnedOffOrder[]);

/**
 * Function to flush an array of 4 elements
 */
void flushArray(int *array);



